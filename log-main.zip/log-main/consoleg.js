console.log("Hello World")
console.log("Anh Thái Gay Chết Mẹ")
