console.log("Hello World");

function main(){
  console.log(1);
}
main()
console.log()
