const sorting_stuff = ['1','2','3'];
sorting_stuff.sort();
